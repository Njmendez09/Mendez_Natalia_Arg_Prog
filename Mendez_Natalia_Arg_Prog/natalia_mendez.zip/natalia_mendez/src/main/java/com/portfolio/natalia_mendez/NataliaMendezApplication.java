package com.portfolio.natalia_mendez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NataliaMendezApplication {

	public static void main(String[] args) {
		SpringApplication.run(NataliaMendezApplication.class, args);
	}

}
