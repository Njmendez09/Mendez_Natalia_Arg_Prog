package com.portfolio.natalia_mendez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NataliaMendezApplicationTests {

	@Test
	void contextLoads() {
	}

}
